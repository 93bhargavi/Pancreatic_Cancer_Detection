from flask import Flask, render_template, request
import pickle
import numpy as np
from sklearn.preprocessing import StandardScaler

app = Flask(__name__)
model = pickle.load(open('random_forest_model.pkl', 'rb'))
standard_to = StandardScaler()

@app.route('/', methods=['GET'])
def Home():
    return render_template('website_pancreas.html')

@app.route("/predict", methods=['POST'])
def predict():
    if request.method == 'POST':
        patient_cohort = request.form['patient_cohort']
        sex = request.form['sex']
        stage = int(request.form['stage'])
        creatinine = float(request.form['creatinine'])
        lyve1 = float(request.form['lyve1'])
        sample_origin = request.form['sample_origin']
        tff1 = float(request.form['tff1'])
        age = int(request.form['age'])
        reg1a = float(request.form['reg1a'])
        reg1b = float(request.form['reg1b'])
        plasma_CA19_9 = float(request.form['plasma_CA19_9'])
        benign_sample_diagnosis = request.form['benign_sample_diagnosis']
        
        prediction = model.predict([[patient_cohort, age, sex, stage, creatinine, lyve1, sample_origin, tff1, reg1a, reg1b, plasma_CA19_9, benign_sample_diagnosis]])
        print(prediction)
        
        if prediction[0] == 1:
            return render_template('website_pancreas.html', prediction_text="YOU ARE SAFE")
        elif prediction[0] == 2:
            return render_template('website_pancreas.html', prediction_text="YOU ARE WITH Pancreatic Cancer")
    else:
        return render_template('website_pancreas.html')

if __name__ == "__main__":
    app.run(debug=True)
